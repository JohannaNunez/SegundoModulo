# Simple Node.js

Servidor de archivos estáticos simple en Node.js (sin frameworks)

Basado en el articulo *Servidor Node sin framework* (https://developer.mozilla.org/es/docs/Learn/Server-side/Node_server_without_framework)